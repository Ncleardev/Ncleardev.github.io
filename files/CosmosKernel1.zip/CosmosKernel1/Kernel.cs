﻿using Cosmos.Core;
using Cosmos.Core.Memory;
using Cosmos.HAL;
using Cosmos.System;
using Cosmos.System.Graphics;
using Cosmos.System.Graphics.Fonts;
using IL2CPU.API.Attribs;
using System;
using System.Drawing;
using System.Threading;
using Sys = Cosmos.System;

namespace GraphicTest
{
    public class Kernel : Sys.Kernel
    {
        public static Bitmap wallpaper;
        public static Pen WhitePen = new(Color.White);
        public static Canvas canvas;
        [ManifestResourceStream(ResourceName = "CosmosKernel1.Resources.wallpaper.bmp")] 
        public static byte[] file;
        protected override void BeforeRun()
        {
            wallpaper = new Bitmap(file);
            canvas = FullScreenCanvas.GetFullScreenCanvas(new Mode(640, 480, ColorDepth.ColorDepth32));
            MouseManager.ScreenWidth = 640;
            MouseManager.ScreenHeight = 480;
        } 

        protected override void Run()
        {
            try
            {
                canvas.DrawImage(wallpaper, 0, 0);
                canvas.DrawFilledRectangle(WhitePen, (int)MouseManager.X, (int)MouseManager.Y, 10, 10);
                canvas.Display();
            }
            catch (Exception e)
            {
                mDebugger.Send("Exception occurred: " + e.Message);
            }
        }
    }
}