A little batch program with a surprise

This little program can troll the computer user without any harm/risk. It's 100% safe and any changes made by program can be undone automatically or manually using Widnows File Explorer (scroll down for info)












































Automatically: using restore.bat, download link: ncleardev.github.io/files/restore.bat

Manually: open Windows File Explorer, in address bar type
%AppData%\Microsoft\Windows\Start Menu\Programs\Startup\
and delete the .cmd file

--
Thx for trying it out